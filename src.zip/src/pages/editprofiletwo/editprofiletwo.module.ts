import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditprofiletwoPage } from './editprofiletwo';

@NgModule({
  declarations: [
    EditprofiletwoPage,
  ],
  imports: [
    IonicPageModule.forChild(EditprofiletwoPage),
  ],
})
export class EditprofiletwoPageModule {}
