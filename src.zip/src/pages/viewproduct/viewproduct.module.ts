import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewproductPage } from './viewproduct';

@NgModule({
  declarations: [
    ViewproductPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewproductPage),
  ],
})
export class ViewproductPageModule {}
