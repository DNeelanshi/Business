import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignuptwoPage } from './signuptwo';

@NgModule({
  declarations: [
    SignuptwoPage,
  ],
  imports: [
    IonicPageModule.forChild(SignuptwoPage),
  ],
})
export class SignuptwoPageModule {}
