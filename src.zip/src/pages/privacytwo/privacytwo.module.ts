import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PrivacytwoPage } from './privacytwo';

@NgModule({
  declarations: [
    PrivacytwoPage,
  ],
  imports: [
    IonicPageModule.forChild(PrivacytwoPage),
  ],
})
export class PrivacytwoPageModule {}
