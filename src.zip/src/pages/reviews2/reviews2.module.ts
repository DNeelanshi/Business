import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reviews2Page } from './reviews2';

@NgModule({
  declarations: [
    Reviews2Page,
  ],
  imports: [
    IonicPageModule.forChild(Reviews2Page),
  ],
})
export class Reviews2PageModule {}
