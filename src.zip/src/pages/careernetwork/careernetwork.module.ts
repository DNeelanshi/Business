import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CareernetworkPage } from './careernetwork';

@NgModule({
  declarations: [
    CareernetworkPage,
  ],
  imports: [
    IonicPageModule.forChild(CareernetworkPage),
  ],
})
export class CareernetworkPageModule {}
