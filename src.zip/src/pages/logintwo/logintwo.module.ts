import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LogintwoPage } from './logintwo';

@NgModule({
  declarations: [
    LogintwoPage,
  ],
  imports: [
    IonicPageModule.forChild(LogintwoPage),
  ],
})
export class LogintwoPageModule {}
