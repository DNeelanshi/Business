import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditbusinessPage } from './editbusiness';

@NgModule({
  declarations: [
    EditbusinessPage,
  ],
  imports: [
    IonicPageModule.forChild(EditbusinessPage),
  ],
})
export class EditbusinessPageModule {}
