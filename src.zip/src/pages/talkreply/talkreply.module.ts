import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TalkreplyPage } from './talkreply';

@NgModule({
  declarations: [
    TalkreplyPage,
  ],
  imports: [
    IonicPageModule.forChild(TalkreplyPage),
  ],
})
export class TalkreplyPageModule {}
