import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermsbusinessPage } from './termsbusiness';

@NgModule({
  declarations: [
    TermsbusinessPage,
  ],
  imports: [
    IonicPageModule.forChild(TermsbusinessPage),
  ],
})
export class TermsbusinessPageModule {}
