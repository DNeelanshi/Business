import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewreservationPage } from './viewreservation';

@NgModule({
  declarations: [
    ViewreservationPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewreservationPage),
  ],
})
export class ViewreservationPageModule {}
