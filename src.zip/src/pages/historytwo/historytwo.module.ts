import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HistorytwoPage } from './historytwo';

@NgModule({
  declarations: [
    HistorytwoPage,
  ],
  imports: [
    IonicPageModule.forChild(HistorytwoPage),
  ],
})
export class HistoryPageModule {}
