import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GetstartPage } from './getstart';

@NgModule({
  declarations: [
    GetstartPage,
  ],
  imports: [
    IonicPageModule.forChild(GetstartPage),
  ],
})
export class GetstartPageModule {}
