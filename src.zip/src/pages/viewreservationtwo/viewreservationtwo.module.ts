import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewreservationtwoPage } from './viewreservationtwo';

@NgModule({
  declarations: [
    ViewreservationtwoPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewreservationtwoPage),
  ],
})
export class ViewreservationtwoPageModule {}
