import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OurtalkreplyPage } from './ourtalkreply';

@NgModule({
  declarations: [
    OurtalkreplyPage,
  ],
  imports: [
    IonicPageModule.forChild(OurtalkreplyPage),
  ],
})
export class OurtalkreplyPageModule {}
