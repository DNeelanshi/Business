import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ForgottwoPage } from './forgottwo';

@NgModule({
  declarations: [
    ForgottwoPage,
  ],
  imports: [
    IonicPageModule.forChild(ForgottwoPage),
  ],
})
export class ForgottwoPageModule {}
