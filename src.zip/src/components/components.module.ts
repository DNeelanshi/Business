import { NgModule } from '@angular/core';
import { LocationComponent } from './location/location';
@NgModule({
	declarations: [LocationComponent],
	imports: [],
	exports: [LocationComponent]
})
export class ComponentsModule {}
